package com.legobot.phoneprobe

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Raw LEGO Wireless Protocol (LWP 3.0) message encoding/decoding.
 *
 * hub_controller.py never had to know any of this -- pylgbst hid the wire
 * format behind Python objects (`motor._describe_mode()`, `hub.led`, etc).
 * Android has no pylgbst equivalent, so HubConnector talks LWP directly,
 * and this is the one place that knows the actual byte layouts, straight
 * from LEGO's published spec:
 * https://lego.github.io/lego-ble-wireless-protocol-docs/
 *
 * Every LWP message on the single 1624 characteristic shares a 3-byte
 * Common Header: (Length, HubID=0x00, MessageType), followed by a
 * message-type-specific payload. Length includes itself, and covers the
 * whole message. All of *our* messages are well under 127 bytes, so the
 * escaped 2-byte length encoding (bit 7 set) never applies here --
 * encodeMessage() asserts that rather than silently mis-encoding it.
 */
object Lwp {

    // -- Message Types (LEGO Hub Characteristic 0x1624) --------------------
    const val MSG_PORT_INFO_REQUEST = 0x21          // Down -- "tell me about this port"
    const val MSG_PORT_MODE_INFO_REQUEST = 0x22      // Down -- "tell me about this port's mode"
    const val MSG_PORT_INPUT_FORMAT_SETUP_SINGLE = 0x41 // Down -- subscribe to a mode's live updates
    const val MSG_PORT_INFORMATION = 0x43            // Up   -- reply to 0x21
    const val MSG_PORT_MODE_INFORMATION = 0x44       // Up   -- reply to 0x22
    const val MSG_PORT_VALUE_SINGLE = 0x45           // Up   -- a subscribed mode's live value, unsolicited
    const val MSG_PORT_INPUT_FORMAT_SINGLE = 0x47    // Up   -- reply to 0x41 (subscription confirmed)
    const val MSG_PORT_OUTPUT_COMMAND = 0x81         // Down -- drive a motor/light/etc
    const val MSG_PORT_OUTPUT_COMMAND_FEEDBACK = 0x82 // Up  -- reply to 0x81 (not consumed yet)

    // -- Port Information Request (0x21) "Information Type" ----------------
    // 0x00 = live Port Value, 0x02 = possible mode combinations -- only
    // 0x01 (Mode Info: capabilities + mode count + mode bitmasks) is used
    // here, since that's all describe_port needs to then walk each mode.
    const val PORT_INFO_MODE_INFO = 0x01

    // -- Port Mode Information Request (0x22) "Information Type" -----------
    // Full list per spec is NAME/RAW/PCT/SI/SYMBOL/MAPPING/MOTOR_BIAS/
    // CAPABILITY_BITS/VALUE_FORMAT -- only pulling NAME + RAW here for this
    // first pass (parity with what a human actually reads off
    // hub_controller.py's old describe_port output: mode name + range).
    // Extending to PCT/SI/SYMBOL later is just one more sendAndAwait call
    // per mode in HubConnector.describePort, same shape as these two.
    const val MODE_INFO_NAME = 0x00
    const val MODE_INFO_RAW = 0x01

    // -- Port Output Command (0x81) sub-commands ----------------------------
    const val SUBCMD_WRITE_DIRECT_MODE_DATA = 0x51

    // -- Startup/Completion Information byte (Port Output Command) ---------
    // Low nibble = Completion (0x00 no action, 0x01 request feedback on
    // 0x82), high nibble = Startup (0x00 buffer, 0x10 execute immediately).
    // 0x11 = execute immediately + ask for feedback -- the standard
    // combination every LWP client library (pylgbst/pybricks/
    // node-poweredup) uses for one-shot direct commands like this.
    // Feedback (0x82) isn't parsed yet (see MSG_PORT_OUTPUT_COMMAND_FEEDBACK) --
    // today "success" means the BLE write itself went through.
    const val EXECUTE_IMMEDIATE_WITH_FEEDBACK = 0x11

    // Hub connector ports A-D -- identical mapping to old
    // hub_controller.py's PORTS dict, so port letters mean the same thing
    // on both sides of the Pi->phone migration.
    val PORTS: Map<String, Int> = mapOf("A" to 0x00, "B" to 0x01, "C" to 0x02, "D" to 0x03)

    // Technic angular motor mode numbers -- confirmed via a live
    // describe_port against the actual head-tilt servo (front hub, port
    // B): "0 POWER -100-100 out / 1 SPEED -100-100 out / 2 POS -360-360
    // in-out / 3 APOS -180-179 in-out / 4 LOAD 0-127 in-out". Ground
    // truth from the real device, not the LWP spec's generic numbering
    // (which can vary per device type) or an assumption.
    const val MOTOR_MODE_POWER = 0
    const val MOTOR_MODE_SPEED = 1
    const val MOTOR_MODE_POS = 2   // relative encoder counter -- resets to 0 wherever tracking starts each session
    const val MOTOR_MODE_APOS = 3  // magnet-based TRUE absolute position -- survives reconnects/power cycles
    const val MOTOR_MODE_LOAD = 4

    // The hub's own built-in status LED. Per LEGO's Port ID range (0-49 =
    // physical connectors, 50-100 = internal devices), every Control+/
    // Technic hub has an "RGB Light" permanently attached at port 0x32
    // (50) -- confirmed against independent hub port-dump logs (e.g.
    // pybricks discovery output showing an RGB Light device at
    // "Port: 0x32 / 50" on hubs with no physical port by that name).
    // This is NOT one of the PORTS above -- it's not a connector a motor
    // could ever be plugged into.
    const val HUB_LED_PORT = 0x32

    // RGB Light's Mode 1 ("RGB O") -- direct R/G/B bytes, 0-255 each, per
    // LEGO's own WriteDirectModeData example in the spec text itself
    // ("...set RGB values to 00,33,00 (direct to mode 1)"). CAVEAT (from
    // that same spec passage): a mode-1 write can be accepted and stored
    // without ever becoming VISIBLE if the port's currently *active* mode
    // is still mode 0 -- the spec's own wording ("switching to mode 1
    // will NOT set the 00,33,00...") implies mode 1 only renders once the
    // port has actually been switched into it, which a bare
    // WriteDirectModeData does not do. Confirmed as unreliable on our own
    // hub: describe_port's queries (0x21/0x22) round-trip fine over the
    // same write path, proving BLE delivery works, but a mode-1 LED write
    // alone did not visibly change the light. Kept for completeness /
    // future use (e.g. paired with a Port Input Format Setup switching
    // the port to mode 1 first) but LED_MODE_COLOR below is the reliable
    // path today.
    const val LED_MODE_RGB = 0x01

    // RGB Light's Mode 0 ("COL O") -- LEGO's fixed 11-entry predefined
    // color palette, one index byte. This is the path pylgbst's own
    // README example uses (hub.led.set_color(COLOR_RED)) and the one
    // node-poweredup's Color enum documents -- the actually-proven,
    // widely-used way every other LWP client sets this LED, unlike mode 1
    // above. This is what setHubLedColor()/HubConnector.setLedColor() use.
    const val LED_MODE_COLOR = 0x00

    /** LEGO's fixed Mode-0 color palette for the hub's RGB Light --
     * matches node-poweredup's Color enum and pylgbst's COLORS list
     * exactly (both independently document the same 11 indices), not
     * this project's own guess. NONE (255) turns the LED off/idle
     * (hands color control back to the hub's own firmware, e.g. its
     * battery-low blink) rather than commanding black. */
    object LedColor {
        const val BLACK = 0
        const val PINK = 1
        const val PURPLE = 2
        const val BLUE = 3
        const val LIGHT_BLUE = 4
        const val CYAN = 5
        const val GREEN = 6
        const val YELLOW = 7
        const val ORANGE = 8
        const val RED = 9
        const val WHITE = 10
        const val NONE = 255

        val byName: Map<String, Int> = mapOf(
            "BLACK" to BLACK, "PINK" to PINK, "PURPLE" to PURPLE, "BLUE" to BLUE,
            "LIGHT_BLUE" to LIGHT_BLUE, "CYAN" to CYAN, "GREEN" to GREEN, "YELLOW" to YELLOW,
            "ORANGE" to ORANGE, "RED" to RED, "WHITE" to WHITE, "NONE" to NONE,
        )
    }

    /** Builds one full LWP message: (Length, HubID=0, MessageType, payload...). */
    fun encodeMessage(messageType: Int, vararg payload: Int): ByteArray {
        val body = ByteArray(payload.size + 2)
        body[0] = 0x00 // Hub ID -- "NOT USE at the moment! Always set to 0x00" per spec
        body[1] = messageType.toByte()
        for (i in payload.indices) body[i + 2] = payload[i].toByte()
        val length = body.size + 1 // +1 for the length byte itself
        require(length in 1..127) {
            "message length $length needs the escaped 2-byte length encoding -- " +
                "not implemented, and none of our messages should ever be this long"
        }
        return byteArrayOf(length.toByte()) + body
    }

    fun portInformationRequest(portId: Int): ByteArray =
        encodeMessage(MSG_PORT_INFO_REQUEST, portId, PORT_INFO_MODE_INFO)

    fun portModeInformationRequest(portId: Int, mode: Int, infoType: Int): ByteArray =
        encodeMessage(MSG_PORT_MODE_INFO_REQUEST, portId, mode, infoType)

    /** Builds a Port Output Command (0x81) with an arbitrary sub-command --
     * WriteDirectModeData (0x51) is the special case used for the LED and
     * for direct port-mode writes; motor commands like StartSpeed use
     * this same envelope with their own sub-command byte instead. */
    fun portOutputCommand(portId: Int, subCommand: Int, vararg params: Int): ByteArray =
        encodeMessage(MSG_PORT_OUTPUT_COMMAND, portId, EXECUTE_IMMEDIATE_WITH_FEEDBACK, subCommand, *params)

    fun writeDirectModeData(portId: Int, mode: Int, vararg data: Int): ByteArray =
        portOutputCommand(portId, SUBCMD_WRITE_DIRECT_MODE_DATA, mode, *data)

    fun setHubLedRgb(r: Int, g: Int, b: Int): ByteArray =
        writeDirectModeData(HUB_LED_PORT, LED_MODE_RGB, r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))

    fun setHubLedColor(colorIndex: Int): ByteArray =
        writeDirectModeData(HUB_LED_PORT, LED_MODE_COLOR, colorIndex)

    // -- Motor sub-commands (Output Command 0x81, sub-commands 0x01-0x3F) --
    // NOT WriteDirectModeData -- confirmed against pylgbst's actual
    // Motor class (github.com/undera/pylgbst/blob/master/pylgbst/
    // peripherals.py) that this is a genuinely different sub-command
    // family, same 0x81 envelope but a different byte here than 0x51.
    const val SUBCMD_START_SPEED = 0x07
    const val SUBCMD_START_SPEED_FOR_TIME = 0x09

    // Special values for the "speed"/"power" byte and the "end state"
    // byte -- per pylgbst's Motor class and the LWP spec's StartPower
    // section. FLOAT lets the motor spin freely (no resistance); BRAKE
    // shorts the motor windings (firm stop); HOLD actively drives the
    // motor to counteract whatever's trying to move it (stiffest stop).
    const val END_STATE_FLOAT = 0
    const val END_STATE_HOLD = 126
    const val END_STATE_BRAKE = 127

    /** Converts a -1.0..1.0 caller-facing speed into the signed -100..100
     * byte the wire actually wants -- same scaling pylgbst's
     * abs_scaled_100() does for a normal (non-special) speed value. */
    fun speedToByte(relative: Double): Int = (relative.coerceIn(-1.0, 1.0) * 100).let { Math.round(it).toInt() }

    /** StartSpeed (sub-command 0x07) -- continuous regulated speed, runs
     * until the next motor command. useProfile=0b11 (3) applies both the
     * hub's acceleration and deceleration ramps, matching pylgbst's own
     * default. speedByte is normally speedToByte()'s output, but pass
     * END_STATE_BRAKE/END_STATE_HOLD directly for those special cases --
     * same overload pylgbst's _speed_abs() supports. */
    fun startSpeed(portId: Int, speedByte: Int, maxPowerPct: Int = 100, useProfile: Int = 0b11): ByteArray =
        portOutputCommand(portId, SUBCMD_START_SPEED, speedByte, maxPowerPct.coerceIn(0, 100), useProfile)

    /** StartSpeedForTime (sub-command 0x09) -- runs at speedByte for
     * timeMs milliseconds (hub-side timer, not app-side sleep+stop),
     * then transitions to endState. stopMotor() below is just this at
     * timeMs=0 -- see its own doc for why that specific command (not
     * StartSpeed(0)) is what's proven to actually stop these motors. */
    fun startSpeedForTime(
        portId: Int, timeMs: Int, speedByte: Int,
        maxPowerPct: Int = 100, endState: Int = END_STATE_BRAKE, useProfile: Int = 0b11,
    ): ByteArray {
        val t = timeMs.coerceIn(0, 65535) // u16 -- 65.535s ceiling, well past our 5s LLM-facing cap
        return portOutputCommand(
            portId, SUBCMD_START_SPEED_FOR_TIME,
            t and 0xFF, (t shr 8) and 0xFF, // timeMs as u16 LE
            speedByte, maxPowerPct.coerceIn(0, 100), endState, useProfile,
        )
    }

    /** StartSpeedForTime (sub-command 0x09) with timeMs=0 -- this is
     * pylgbst's own Motor.stop() (`self.timed(0)`), not StartSpeed with
     * speed 0. A zero-duration timed move transitions to endState
     * (BRAKE by default) essentially immediately; replicated exactly
     * rather than "simplified" to StartSpeed(0), since this exact
     * command is what's proven to actually stop these motors on this
     * hardware already (same hubs, driven this way for months under the
     * old Pi relay). */
    fun stopMotor(portId: Int, endState: Int = END_STATE_BRAKE, maxPowerPct: Int = 100, useProfile: Int = 0b11): ByteArray =
        startSpeedForTime(portId, 0, speedToByte(1.0), maxPowerPct, endState, useProfile)

    /** Common Header's Message Type byte (offset 2), or null if too short to have one. */
    fun messageType(bytes: ByteArray): Int? = if (bytes.size >= 3) bytes[2].toInt() and 0xFF else null

    /** Splits a signed 32-bit value into its 4 little-endian bytes (as
     * unsigned Ints, ready for encodeMessage's flat payload) -- needed
     * anywhere a multi-byte field (DeltaInterval, a Degrees/Position
     * value) has to be hand-packed into the flat one-byte-per-Int
     * payload encodeMessage()/portOutputCommand() take. */
    private fun le32(value: Int): IntArray = intArrayOf(
        value and 0xFF, (value shr 8) and 0xFF, (value shr 16) and 0xFF, (value shr 24) and 0xFF,
    )

    /** Port Input Format Setup (Single) (0x41) -- subscribes (or
     * re-subscribes) a port to push live Port Value (Single) (0x45)
     * updates for one mode. deltaInterval=1 means "push an update on
     * every change", the same granularity=1 default pylgbst's own
     * subscribe() uses. Triggers a reply on 0x47 confirming the
     * subscription took, then ongoing unsolicited 0x45 pushes as the
     * value changes -- see HubConnector's aposState cache for how those
     * get consumed. */
    fun portInputFormatSetupSingle(portId: Int, mode: Int, deltaInterval: Int = 1, notificationEnabled: Boolean = true): ByteArray {
        val delta = le32(deltaInterval)
        return encodeMessage(
            MSG_PORT_INPUT_FORMAT_SETUP_SINGLE, portId, mode,
            delta[0], delta[1], delta[2], delta[3],
            if (notificationEnabled) 1 else 0,
        )
    }

    /** Recalibrates a motor's zero reference so its CURRENT physical
     * position becomes `degrees` (0, in the normal case) going forward --
     * pylgbst's preset_encoder(), for a non-virtual/single motor,
     * resolves to exactly this: a WriteDirectModeData write straight to
     * the position mode itself, which the firmware treats as "recalibrate
     * to this value" rather than a normal live-output write. Confirmed
     * against pylgbst's actual source (EncodedMotor.preset_encoder() ->
     * self._write_direct_mode(SENSOR_ANGLE, params) for the single-motor
     * path), not re-derived from the spec alone. Call this only while the
     * motor is actually sitting at the physical position that should
     * become `degrees` -- see HubConnector.presetZero's own doc. */
    fun presetPosition(portId: Int, degrees: Int): ByteArray {
        val d = le32(degrees)
        return writeDirectModeData(portId, MOTOR_MODE_POS, d[0], d[1], d[2], d[3])
    }

    // StartSpeedForDegrees -- confirmed against pylgbst's EncodedMotor.
    // angled(): a genuinely relative move, degrees is UNSIGNED (negative
    // deltas are sent as positive degrees with the speed's sign flipped
    // instead -- see HubConnector.gotoApos for where that flip happens).
    const val SUBCMD_START_SPEED_FOR_DEGREES = 0x0B

    /** StartSpeedForDegrees (sub-command 0x0B) -- relative regulated move
     * of exactly `degrees` (must be >= 0; see SUBCMD_START_SPEED_FOR_DEGREES's
     * doc for why), then holds at endState. */
    fun startSpeedForDegrees(
        portId: Int, degrees: Int, speedByte: Int,
        maxPowerPct: Int = 100, endState: Int = END_STATE_BRAKE, useProfile: Int = 0b11,
    ): ByteArray {
        require(degrees >= 0) { "degrees must be >= 0 -- negative deltas are sent as positive degrees with speed's sign flipped instead" }
        val d = le32(degrees)
        return portOutputCommand(
            portId, SUBCMD_START_SPEED_FOR_DEGREES,
            d[0], d[1], d[2], d[3], speedByte, maxPowerPct.coerceIn(0, 100), endState, useProfile,
        )
    }

    /** Common Header's Port ID byte (offset 3), or null if too short to
     * have one -- used to route an unsolicited Port Value (Single) (0x45)
     * push to the right port's cached state. */
    fun messagePortId(bytes: ByteArray): Int? = if (bytes.size >= 4) bytes[3].toInt() and 0xFF else null

    /** Parses a Port Value (Single) (0x45) push for APOS (mode 3):
     * (len, hub=0, 0x45, portId, apos: int16 LE) -- 6 bytes total, matching
     * the confirmed 16-bit signed / -180..179 range from describe_port. */
    fun parseApos(bytes: ByteArray): Int? {
        if (bytes.size < 6) return null
        return ByteBuffer.wrap(bytes, 4, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
    }

    data class PortModeInfo(
        val capabilities: Int,
        val totalModeCount: Int,
        val inputModes: Int,   // bitmask, bit N set = mode N usable as input
        val outputModes: Int,  // bitmask, bit N set = mode N usable as output
    )

    /** Parses a Port Information (0x43) reply to a Mode Info (0x01) request.
     * Layout: (len, hub=0, 0x43, portId, infoType=0x01, capabilities,
     *          totalModeCount, inputModes:u16 LE, outputModes:u16 LE) -- 11 bytes total,
     * matching the spec's "Information Type 0x01 : 11 Bytes". */
    fun parsePortInformationModeInfo(bytes: ByteArray): PortModeInfo? {
        if (bytes.size < 11) return null
        val capabilities = bytes[5].toInt() and 0xFF
        val totalModeCount = bytes[6].toInt() and 0xFF
        val inputModes = (bytes[7].toInt() and 0xFF) or ((bytes[8].toInt() and 0xFF) shl 8)
        val outputModes = (bytes[9].toInt() and 0xFF) or ((bytes[10].toInt() and 0xFF) shl 8)
        return PortModeInfo(capabilities, totalModeCount, inputModes, outputModes)
    }

    /** Parses a Port Mode Information (0x44) reply to a NAME (0x00) request.
     * Layout: (len, hub=0, 0x44, portId, mode, infoType=0x00, name: NUL-padded ASCII, rest of message). */
    fun parseModeName(bytes: ByteArray): String {
        if (bytes.size <= 6) return ""
        val raw = bytes.copyOfRange(6, bytes.size)
        val nul = raw.indexOf(0)
        val trimmed = if (nul >= 0) raw.copyOfRange(0, nul) else raw
        return String(trimmed, Charsets.US_ASCII)
    }

    /** Parses a Port Mode Information (0x44) reply to a RAW (0x01) request.
     * Layout: same header as parseModeName, then (min: float32 LE, max: float32 LE) -- 14 bytes total,
     * matching the spec's "Information Type 0x01 : 14 Bytes". Returns null if too short to hold both floats. */
    fun parseModeRawRange(bytes: ByteArray): Pair<Float, Float>? {
        if (bytes.size < 14) return null
        val bb = ByteBuffer.wrap(bytes, 6, 8).order(ByteOrder.LITTLE_ENDIAN)
        val min = bb.float
        val max = bb.float
        return min to max
    }
}
