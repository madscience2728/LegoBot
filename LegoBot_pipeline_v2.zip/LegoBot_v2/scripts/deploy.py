"""
deploy.py -- push src/lego_pi/ and src/lego_control/ to the Pi and
(re)start the relay.

Both packages are uploaded because lego_pi imports lego_control -- on
the Pi they need to land as sibling directories under the home dir, not
nested under a src/ folder (that nesting is a PC-repo-organization
choice, not something the Pi's import path needs to know about).

Usage:
    python3 scripts/deploy.py

Reads credentials from environment variables (set once per machine):
    LEGOBOT_PI_HOST   e.g. legobot.local or 192.168.4.89
    LEGOBOT_PI_USER   e.g. pi
    LEGOBOT_PI_PASS

Requires: paramiko   (pip install paramiko)

Note: this restarts a systemd service called "legobot-relay" if one
exists. If you haven't set that up yet, the restart step will just warn
and move on -- the upload still happens, you'd start the relay manually
with `python3 -m lego_pi` from the Pi in that case. See SpiderBot's
robot_files/spider-robot.service + docs/SYSTEMD_REFERENCE.md for the
unit file to copy once you're ready to make it persistent.
"""

import os
import sys
from pathlib import Path

import paramiko

_REPO_ROOT = Path(__file__).parent.parent
LOCAL_PACKAGES = ["lego_pi", "lego_control"]
SERVICE_NAME = "legobot-relay"
SKIP_DIRS = {"__pycache__"}


def get_credentials():
    host = os.environ.get("LEGOBOT_PI_HOST")
    user = os.environ.get("LEGOBOT_PI_USER")
    password = os.environ.get("LEGOBOT_PI_PASS")
    missing = [name for name, val in [
        ("LEGOBOT_PI_HOST", host),
        ("LEGOBOT_PI_USER", user),
        ("LEGOBOT_PI_PASS", password),
    ] if not val]
    if missing:
        print(f"Missing environment variable(s): {', '.join(missing)}")
        print("Set them, then open a NEW terminal before running this script.")
        sys.exit(1)
    return host, user, password


def upload_directory(sftp: paramiko.SFTPClient, local_dir: Path, remote_dir: str):
    try:
        sftp.mkdir(remote_dir)
    except IOError:
        pass  # already exists -- fine

    for item in sorted(local_dir.iterdir()):
        if item.name in SKIP_DIRS:
            continue
        remote_path = f"{remote_dir}/{item.name}"
        if item.is_dir():
            upload_directory(sftp, item, remote_path)
        else:
            print(f"  uploading {item.relative_to(local_dir.parent.parent)}")
            sftp.put(str(item), remote_path)


def run_remote_command(client: paramiko.SSHClient, command: str, password: str, sudo: bool = False):
    full_cmd = f"sudo -S {command}" if sudo else command
    stdin, stdout, stderr = client.exec_command(full_cmd, get_pty=True)
    if sudo:
        stdin.write(f"{password}\n")
        stdin.flush()
    exit_status = stdout.channel.recv_exit_status()
    out = stdout.read().decode(errors="ignore")
    err = stderr.read().decode(errors="ignore")
    return exit_status, out, err


def main():
    host, user, password = get_credentials()

    src_dir = _REPO_ROOT / "src"
    for pkg in LOCAL_PACKAGES:
        if not (src_dir / pkg).is_dir():
            print(f"Can't find local package folder: {src_dir / pkg}")
            sys.exit(1)

    print(f"Connecting to {host} as {user}...")
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname=host, username=user, password=password, timeout=10)

    sftp = client.open_sftp()
    for pkg in LOCAL_PACKAGES:
        print(f"Uploading src/{pkg}/ -> ~/{pkg}/ ...")
        upload_directory(sftp, src_dir / pkg, pkg)
    sftp.close()
    print("Upload complete.")

    print(f"Restarting {SERVICE_NAME} service (if it exists)...")
    status, out, err = run_remote_command(
        client, f"systemctl restart {SERVICE_NAME}", password, sudo=True
    )
    if status != 0:
        print(f"  {SERVICE_NAME} isn't set up as a service yet (that's fine for now).")
        print("  Start it manually on the Pi with: python3 -m lego_pi")
    else:
        status, out, err = run_remote_command(
            client, f"systemctl is-active {SERVICE_NAME}", password, sudo=True
        )
        print(f"Service state: {out.strip() or err.strip()}")

    client.close()
    print("Done.")


if __name__ == "__main__":
    main()
