"""
robot_client.py -- the ONLY place your app code should talk to LegoBot.

This is the "universal adapter" from the design discussion: callers use
goto_angle(), set_speed(), stop() and never know or care whether the
command went over HTTP to the Pi relay or straight out the PC's own
Bluetooth radio. Both paths ultimately run the exact same
hub_controller code (see lego_control/hub_controller.py) -- this module
only decides WHICH machine's radio does the talking.

Routing rule:
    1. Ping the Pi relay's /health.
    2. Reachable -> POST the command there (relay's radio talks to hub).
    3. Not reachable -> fall back to a local HubController and call BLE
       directly from this machine.

Caveat: BLE supports one active central connection to the hub at a time.
If you've been running in bypass mode, the PC currently holds that
connection -- bring the Pi relay back up and it will happily take over
next call (this module always re-checks /health rather than caching the
route forever), but don't expect both routes to work simultaneously.

Env vars (same idea as SpiderBot's SPIDER_BOT_HOST):
    LEGOBOT_PI_HOST   -- Pi's hostname or IP, e.g. "legobot.local"
    LEGOBOT_PI_PORT   -- default 8000
    LEGOBOT_HUB_NAME  -- default "Control+ Hub"
"""

import os
import threading

import requests

from lego_control.hub_controller import HubController, dispatch

PI_PORT = int(os.environ.get("LEGOBOT_PI_PORT", "8000"))
HUB_NAME = os.environ.get("LEGOBOT_HUB_NAME", "Control+ Hub")

_local_controller = None
_local_lock = threading.Lock()


def _pi_base_url():
    host = os.environ.get("LEGOBOT_PI_HOST")
    if not host:
        return None
    return f"http://{host}:{PI_PORT}"


def _pi_reachable(base_url: str, timeout: float = 1.5) -> bool:
    try:
        r = requests.get(f"{base_url}/health", timeout=timeout)
        return r.ok
    except requests.RequestException:
        return False


def _local() -> HubController:
    """Lazily connect a local (PC) BLE controller -- only touched the
    first time the Pi relay turns out to be unreachable, so a healthy
    Pi setup never has the PC's own Bluetooth radio scanning at all."""
    global _local_controller
    with _local_lock:
        if _local_controller is None:
            controller = HubController(hub_name=HUB_NAME)
            controller.connect()
            _local_controller = controller
        return _local_controller


def _send(cmd: str, args: dict, timeout: float = 15.0) -> dict:
    base_url = _pi_base_url()

    if base_url and _pi_reachable(base_url):
        try:
            r = requests.post(
                f"{base_url}/command", json={"cmd": cmd, "args": args}, timeout=timeout
            )
            r.raise_for_status()
            result = r.json()
            result["_route"] = "pi_relay"
            return result
        except requests.RequestException as e:
            print(f"[robot_client] Pi relay call failed mid-flight ({e}), "
                  f"falling back to direct BLE for this command.")

    result = dispatch(_local(), cmd, args)
    result["_route"] = "direct_ble"
    return result


# -- public API --------------------------------------------------------
# Mirrors HubController's methods 1:1. If you add a command to
# hub_controller.COMMANDS, add the matching one-liner here too.

def health() -> dict:
    base_url = _pi_base_url()
    if base_url and _pi_reachable(base_url):
        r = requests.get(f"{base_url}/health", timeout=3)
        r.raise_for_status()
        result = r.json()
        result["_route"] = "pi_relay"
        return result
    result = _local().health()
    result["_route"] = "direct_ble"
    return result


def stop(port: str = "A") -> dict:
    return _send("stop", {"port": port})


def set_speed(port: str, speed: float) -> dict:
    return _send("set_speed", {"port": port, "speed": speed})


def read_angle(port: str = "A") -> dict:
    return _send("read_angle", {"port": port})


def goto_angle(port: str, target_degrees: float, **kwargs) -> dict:
    return _send("goto_angle", {"port": port, "target_degrees": target_degrees, **kwargs})
