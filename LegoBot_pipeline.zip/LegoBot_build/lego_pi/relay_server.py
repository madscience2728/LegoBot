"""
relay_server.py -- runs ON THE PI.

Deliberately dumb. This file does not know what "goto_angle" means -- it
just takes a {"cmd": ..., "args": ...} body off the wire and hands it to
lego_control.hub_controller.dispatch(), which is the same dispatch used
if the PC bypasses this relay entirely and talks BLE directly. If you
find yourself wanting to add robot-specific logic in THIS file, it
belongs in hub_controller.py instead -- that's what keeps the relay a
true 1:1 pass-through instead of a second brain.

Run with:
    pip install fastapi uvicorn
    uvicorn lego_pi.relay_server:app --host 0.0.0.0 --port 8000

Suggested: wire this into a systemd unit (see SpiderBot's
robot_files/spider-robot.service for the pattern) so it's running
persistently and doesn't need a manual SSH session.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from lego_control.hub_controller import HubController, HubNotReady, dispatch

app = FastAPI()
controller = HubController()


class Command(BaseModel):
    cmd: str
    args: dict = {}


@app.on_event("startup")
def _connect_on_startup():
    try:
        controller.connect()
    except Exception as e:
        # Don't crash the relay if the hub isn't on/paired yet -- /health
        # will just report connected: false until someone fixes that and
        # calls /connect (or restarts the service).
        print(f"[relay] warning: initial connect failed: {e}")


@app.get("/health")
def health():
    return controller.health()


@app.post("/connect")
def connect():
    try:
        controller.connect()
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"connect failed: {e}")
    return controller.health()


@app.post("/command")
def command(body: Command):
    try:
        return dispatch(controller, body.cmd, body.args)
    except HubNotReady as e:
        raise HTTPException(status_code=409, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"hub command failed: {e}")
