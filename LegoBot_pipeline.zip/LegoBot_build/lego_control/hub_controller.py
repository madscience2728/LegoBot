"""
hub_controller.py -- the ONLY place BLE/pylgbst logic lives.

Both the Pi relay (lego_pi/relay_server.py) and the PC bypass path
(lego_brain/robot_client.py, when the Pi relay isn't reachable) import
THIS SAME CLASS and call THIS SAME CODE. Whichever machine's Bluetooth
radio ends up talking to the hub, the actual command logic is identical --
there is no separate "Pi version" and "PC version" of goto_angle or
set_speed to keep in sync.

This module has zero networking code in it. It doesn't know or care
whether it's being driven by an HTTP handler on the Pi or a direct call
on the PC. That separation is what makes the relay a true 1:1 passthrough
instead of a second implementation.

pip install "pylgbst[bleak]"
"""

import time
from struct import pack

import bleak

# --- bleak compatibility patch (pylgbst calls the old removed bleak.discover) ---
if not hasattr(bleak, "discover"):
    from bleak import BleakScanner

    async def _discover(timeout=5.0, **kwargs):
        return await BleakScanner.discover(timeout=timeout, **kwargs)

    bleak.discover = _discover
# ---------------------------------------------------------------------------

from pylgbst import get_connection_bleak
from pylgbst.hub import Hub

PORTS = {"A": 0x00, "B": 0x01, "C": 0x02, "D": 0x03}


class HubNotReady(RuntimeError):
    """Raised when a command is sent before connect() succeeded, or the
    requested port has no motor attached."""


class HubController:
    """
    Wraps a single BLE connection to one Technic Control+ Hub.

    NOTE: BLE only supports one active central connection to the hub at a
    time. Whichever process calls connect() successfully first "owns" the
    hub until it disconnects -- this class doesn't do any arbitration
    itself, that's the caller's (robot_client's) job.
    """

    def __init__(self, hub_name: str = "Control+ Hub"):
        self.hub_name = hub_name
        self._connection = None
        self._hub = None

    # -- lifecycle -----------------------------------------------------

    def connect(self, wait_for_port: str = "A", timeout: float = 5.0) -> None:
        self._connection = get_connection_bleak(hub_name=self.hub_name)
        self._hub = Hub(self._connection)

        # Give the requested port a moment to enumerate so an immediate
        # command right after connect() doesn't race an empty peripherals
        # dict. Not fatal if it never shows up -- individual commands will
        # raise HubNotReady when they actually need that port.
        deadline = time.time() + timeout
        port_code = PORTS.get(wait_for_port.upper())
        while time.time() < deadline:
            if port_code is not None and self._hub.peripherals.get(port_code):
                break
            time.sleep(0.1)

    def disconnect(self) -> None:
        if self._connection is not None:
            try:
                self._connection.disconnect()
            except Exception:
                pass
        self._connection = None
        self._hub = None

    @property
    def connected(self) -> bool:
        return self._hub is not None

    def health(self) -> dict:
        return {
            "connected": self.connected,
            "hub_name": self.hub_name,
            "ports_attached": [
                name for name, code in PORTS.items()
                if self.connected and self._hub.peripherals.get(code) is not None
            ] if self.connected else [],
        }

    # -- internal --------------------------------------------------------

    def _motor(self, port: str):
        if not self.connected:
            raise HubNotReady("hub is not connected")
        code = PORTS.get(port.upper())
        if code is None:
            raise HubNotReady(f"unknown port {port!r}, expected one of {list(PORTS)}")
        motor = self._hub.peripherals.get(code)
        if motor is None:
            raise HubNotReady(f"no motor attached on port {port}")
        return motor

    @staticmethod
    def _start_speed_nonblocking(motor, speed, max_power=1.0, use_profile=0b11):
        """Same wire command as motor.start_speed(), sent with
        wait_complete=False -- see tests/goto_angle_closed_loop.py for why
        the stock blocking call doesn't work for a tight control loop."""
        params = b""
        params += pack("<b", motor._speed_abs(speed))
        params += pack("<B", int(100 * max_power))
        params += pack("<B", use_profile)
        motor._send_cmd(motor.SUBCMD_START_SPEED, params, wait_complete=False)

    # -- commands --------------------------------------------------------
    # Each of these is a self-contained unit of work: one dict in, one
    # dict out. That's deliberate -- it's what lets relay_server.py and
    # robot_client.py both dispatch on the same {"cmd": ..., "args": ...}
    # shape without any translation layer in between.

    def stop(self, port: str = "A") -> dict:
        motor = self._motor(port)
        motor.stop()
        return {"ok": True, "port": port}

    def set_speed(self, port: str, speed: float) -> dict:
        """Continuous speed, -1.0..1.0. Runs until the next stop/command."""
        motor = self._motor(port)
        self._start_speed_nonblocking(motor, speed)
        return {"ok": True, "port": port, "speed": speed}

    def read_angle(self, port: str = "A", timeout: float = 2.0) -> dict:
        motor = self._motor(port)
        state = {"angle": None}

        def on_angle(angle):
            state["angle"] = angle

        motor.subscribe(on_angle, mode=motor.SENSOR_ANGLE)
        deadline = time.time() + timeout
        try:
            while state["angle"] is None and time.time() < deadline:
                time.sleep(0.01)
        finally:
            motor.unsubscribe(on_angle)

        if state["angle"] is None:
            raise HubNotReady(f"no angle data from encoder on port {port}")
        return {"port": port, "angle": state["angle"]}

    def goto_angle(
        self,
        port: str,
        target_degrees: float,
        tolerance: float = 2.0,
        kp: float = 0.012,
        min_speed: float = 0.16,
        max_speed: float = 0.6,
        settle_reads: int = 5,
        poll_interval: float = 0.02,
        timeout: float = 6.0,
    ) -> dict:
        """Closed-loop move, ported from tests/goto_angle_closed_loop.py.
        See that file's docstring for why this exists instead of the
        stock motor.goto_position()."""
        motor = self._motor(port)
        state = {"angle": None}

        def on_angle(angle):
            state["angle"] = angle

        motor.subscribe(on_angle, mode=motor.SENSOR_ANGLE)

        start_wait = time.time()
        while state["angle"] is None:
            if time.time() - start_wait > 2.0:
                motor.unsubscribe(on_angle)
                raise HubNotReady(f"no angle data from encoder on port {port}")
            time.sleep(0.01)

        consecutive_in_tolerance = 0
        start_time = time.time()
        settled = False

        try:
            while True:
                if time.time() - start_time > timeout:
                    break

                error = target_degrees - state["angle"]

                if abs(error) <= tolerance:
                    consecutive_in_tolerance += 1
                    if consecutive_in_tolerance >= settle_reads:
                        settled = True
                        break
                    speed = min_speed * (1 if error >= 0 else -1) * 0.5
                else:
                    consecutive_in_tolerance = 0
                    raw_speed = kp * error
                    magnitude = min(max(abs(raw_speed), min_speed), max_speed)
                    speed = magnitude if error > 0 else -magnitude

                self._start_speed_nonblocking(motor, speed)
                time.sleep(poll_interval)
        finally:
            motor.stop()
            motor.unsubscribe(on_angle)

        final_angle = state["angle"]
        return {
            "ok": True,
            "port": port,
            "settled": settled,
            "final_angle": final_angle,
            "target": target_degrees,
            "error": target_degrees - final_angle,
        }


# Single dispatch table shared by relay_server.py (HTTP -> dict -> here)
# and robot_client.py (direct call -> dict -> here). Adding a new command
# means adding one method above and one line here -- nowhere else.
COMMANDS = {
    "stop": HubController.stop,
    "set_speed": HubController.set_speed,
    "read_angle": HubController.read_angle,
    "goto_angle": HubController.goto_angle,
}


def dispatch(controller: HubController, cmd: str, args: dict) -> dict:
    if cmd not in COMMANDS:
        raise ValueError(f"unknown command {cmd!r}, expected one of {list(COMMANDS)}")
    return COMMANDS[cmd](controller, **args)
